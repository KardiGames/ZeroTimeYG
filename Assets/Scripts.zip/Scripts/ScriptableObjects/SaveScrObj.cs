using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "Save", menuName = "Save")]
public class SaveScrObj:ScriptableObject
{
	public string Save;
}
