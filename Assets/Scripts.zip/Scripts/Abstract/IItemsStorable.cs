public interface IItemsStorable
{

}
