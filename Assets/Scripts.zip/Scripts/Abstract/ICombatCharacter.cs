public interface ICombatCharacter
{

}
